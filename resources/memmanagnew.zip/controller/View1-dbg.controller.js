sap.ui.define(
  ["sap/ui/core/mvc/Controller"],
  /**
   * @param {typeof sap.ui.core.mvc.Controller} Controller
   */
  function (Controller) {
    "use strict";

    return Controller.extend("memmanagnew.controller.View1", {
      onInit: function () {},
      	onItemSelect: function (oEvent) {
			var oItem = oEvent.getParameter("item");
			this.byId("pageContainer").to(this.getView().createId(oItem.getKey()));
		},
      handleLineItemPress: function (oEvent) {
        console.log("clicked");
        var oItem = oEvent.getSource();
        var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
        oRouter.navTo("TargetViewTo", {ArcObject : oItem.getBindingContext().getPath().substr(1)});
      },
    });
  }
);
